# Xenium A–C 级数据 Linux 批量下载包

批次：`xenium_ac_20260722`。来源为 Xenium `0.3.0` 初步排序前 24 篇（A=10、B=6、C=8）及其逐篇 L2 dataset observations。

本包包含 24 篇论文、68 个规范化 dataset identity、69 个 data-asset observation。其中 31 个公开主 Xenium 资产组默认纳入；其余 38 个配对、补充、替代或非公开记录只保留关系，除非显式加入。

## 安全模型

- Python 3.9+，仅用标准库；默认只生成 `download_plan.json`，不下载。
- 真正下载必须同时提供 `--apply --confirm-reviewed xenium_ac_20260722`。
- 只接受 HTTPS 与内置域名白名单；支持断点续传、重试、并发、已知 checksum 校验，并为每个完成文件记录 SHA-256。
- 本包不含凭据，不绕过登录、验证码、许可或受控访问。下载结果与 ledger 应留在下游服务器，不回写本项目 registry。

## 推荐运行顺序

```bash
cd xenium_ac_20260722_linux_download

# 1. 联网解析 repository manifest，但只生成计划
python3 download_xenium_ac.py --output-root /data/xenium_ac

# 2. 先下载 A 级（排名 1–10）；建议同时给出容量上限
python3 download_xenium_ac.py --tiers A --ranks 1-10 \
  --output-root /data/xenium_ac --max-workers 4 --max-total-gb 2000 \
  --apply --confirm-reviewed xenium_ac_20260722

# 3. 审阅后继续 B、C
python3 download_xenium_ac.py --tiers B,C \
  --output-root /data/xenium_ac --max-workers 4 \
  --apply --confirm-reviewed xenium_ac_20260722
```

`--offline` 仅使用审计时已经记录的直链；`--include-alternates` 会加入配对 scRNA/bulk/Visium、补充文件等非默认记录。可用 `--work-item awi_...` 或 `--ranks 3,5-8` 精确选择。未知文件大小不计入 `--max-total-gb`，因此执行前仍须人工检查计划。

## 输出

- `download_plan.json`：当次解析后的逐文件 URL、路径、已知大小与 resolver 错误。
- `download_results.jsonl`：实际下载 ledger；含状态、字节数、SHA-256、耗时和错误。
- 目录按 `tier/rank/paper/dataset` 组织。共享 dataset URL 在同一次执行中只下载一次。

## 已知边界

GEO、Zenodo、Figshare、BioStudies、10x dataset page 和 Pennsieve 使用公开 API/manifest 动态解析。远端页面结构、record version、文件名和许可可能变化；plan 是执行时快照。大型 archive 内部成员与格式完整性不在本脚本中验证，应由 Xenium 下游 ingestion pipeline 继续审计。

截至本批次生成时，Zenodo `17285218` 是“record 公开、files restricted”，脚本只报告 blocker，不会绕过访问控制。肾病 atlas 的旧记录 `18674907` 文件受限，但同一 observation 已包含开放新版 `19868428`，下载计划会使用开放新版文件并保留旧版 blocker。
