#!/usr/bin/env python3
"""Resolve and download a reviewed Xenium handoff bundle on Linux.

The script uses only the Python standard library.  It is dry-run by default;
downloads require both --apply and --confirm-reviewed <batch_id>.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import html
import json
import os
import re
import shutil
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable


USER_AGENT = "ScientificLiteratureIntake-XeniumDownloader/1.0"
DEFAULT_ALLOWED_SUFFIXES = {
    "10xgenomics.com",
    "amazonaws.com",
    "biostudies.org",
    "ebi.ac.uk",
    "figshare.com",
    "ftp.ncbi.nlm.nih.gov",
    "huggingface.co",
    "ncbi.nlm.nih.gov",
    "pennsieve.io",
    "springernature.com",
    "static-content.springer.com",
    "zenodo.org",
}
DIRECT_EXTENSIONS = {
    ".7z", ".bz2", ".csv", ".gz", ".h5", ".h5ad", ".html", ".json",
    ".loom", ".mtx", ".parquet", ".rds", ".tar", ".tif", ".tiff",
    ".tsv", ".txt", ".xlsx", ".xml", ".xz", ".zarr", ".zip",
}


@dataclass(frozen=True)
class RemoteFile:
    url: str
    name: str
    size: int | None = None
    checksum: str | None = None
    source: str = "manifest"


def request(url: str, *, headers: dict[str, str] | None = None, timeout: int = 60):
    merged = {"User-Agent": USER_AGENT, "Accept": "*/*"}
    if headers:
        merged.update(headers)
    return urllib.request.urlopen(urllib.request.Request(url, headers=merged), timeout=timeout)


def get_bytes(url: str, timeout: int = 60) -> bytes:
    with request(url, timeout=timeout) as response:
        return response.read()


def get_json(url: str, timeout: int = 60) -> Any:
    return json.loads(get_bytes(url, timeout=timeout).decode("utf-8"))


def safe_name(value: str, fallback: str = "download") -> str:
    value = urllib.parse.unquote(value).strip().replace("\\", "_").replace("/", "_")
    value = re.sub(r"[^A-Za-z0-9._+()=-]+", "_", value).strip("._")
    return value[:220] or fallback


def url_filename(url: str) -> str:
    path = urllib.parse.urlsplit(url).path.rstrip("/")
    return safe_name(Path(path).name or "download")


def is_direct_file_url(url: str) -> bool:
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != "https":
        return False
    if "download=true" in parsed.query.lower():
        return True
    lower = parsed.path.lower()
    return any(lower.endswith(ext) or f"{ext}." in lower for ext in DIRECT_EXTENSIONS)


def allowed_url(url: str, extra_suffixes: Iterable[str] = ()) -> bool:
    parsed = urllib.parse.urlsplit(url)
    host = (parsed.hostname or "").lower().rstrip(".")
    if parsed.scheme != "https" or not host:
        return False
    allowed = DEFAULT_ALLOWED_SUFFIXES | {x.lower().lstrip(".") for x in extra_suffixes}
    return any(host == suffix or host.endswith("." + suffix) for suffix in allowed)


def extract_http_links(text: str) -> list[str]:
    text = html.unescape(text.replace("\\/", "/"))
    links = re.findall(r"https://[^\s\"'<>\\]+", text)
    return sorted({link.rstrip("),.;") for link in links})


def list_http_directory(url: str, timeout: int = 60) -> list[RemoteFile]:
    body = get_bytes(url, timeout=timeout).decode("utf-8", errors="replace")
    found: list[RemoteFile] = []
    for href in re.findall(r"href=[\"']([^\"']+)[\"']", body, flags=re.IGNORECASE):
        href = html.unescape(href)
        if href.startswith("?") or href in {"../", "./"} or href.endswith("/"):
            continue
        resolved = urllib.parse.urljoin(url, href)
        if is_direct_file_url(resolved):
            found.append(RemoteFile(resolved, url_filename(resolved), source="directory_listing"))
    return found


def geo_bucket(accession: str) -> str:
    match = re.fullmatch(r"(GS[EM])(\d+)", accession.upper())
    if not match:
        raise ValueError(f"Unsupported GEO accession: {accession}")
    prefix, digits = match.groups()
    return f"{prefix}{digits[:-3]}nnn" if len(digits) > 3 else f"{prefix}nnn"


def resolve_geo(spec: dict[str, Any], timeout: int = 60) -> list[RemoteFile]:
    accession = str(spec["accession"]).upper()
    accessions = [accession]
    if accession.startswith("GSE"):
        soft_url = (
            "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?"
            + urllib.parse.urlencode({"acc": accession, "targ": "self", "form": "text", "view": "full"})
        )
        text = get_bytes(soft_url, timeout=timeout).decode("utf-8", errors="replace")
        accessions.extend(sorted(set(re.findall(r"\bGSM\d+\b", text))))
    directories = []
    for acc in accessions:
        kind = "series" if acc.startswith("GSE") else "samples"
        directories.append(f"https://ftp.ncbi.nlm.nih.gov/geo/{kind}/{geo_bucket(acc)}/{acc}/suppl/")

    def safe_listing(directory: str) -> list[RemoteFile]:
        try:
            return list_http_directory(directory, timeout=timeout)
        except (urllib.error.HTTPError, urllib.error.URLError):
            return []

    files: list[RemoteFile] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(4, len(directories))) as executor:
        for listing in executor.map(safe_listing, directories):
            files.extend(listing)
    return files


def resolve_zenodo(spec: dict[str, Any], timeout: int = 60) -> list[RemoteFile]:
    record_id = str(spec["record_id"])
    files: list[RemoteFile] = []
    try:
        payload = get_json(f"https://zenodo.org/api/records/{record_id}", timeout=timeout)
        for item in payload.get("files", []):
            links = item.get("links", {})
            url = links.get("content") or links.get("self")
            if not url:
                continue
            files.append(
                RemoteFile(
                    url=url,
                    name=safe_name(item.get("key") or url_filename(url)),
                    size=item.get("size"),
                    checksum=item.get("checksum"),
                    source="zenodo_api",
                )
            )
    except urllib.error.HTTPError as exc:
        if exc.code not in {401, 403}:
            raise
    if not files:
        page_url = f"https://zenodo.org/records/{record_id}"
        body = get_bytes(page_url, timeout=timeout).decode("utf-8", errors="replace")
        for href in re.findall(r"href=[\"']([^\"']*?/files/[^\"']+)[\"']", body, flags=re.IGNORECASE):
            url = urllib.parse.urljoin(page_url, html.unescape(href))
            if is_direct_file_url(url):
                files.append(RemoteFile(url, url_filename(url), source="zenodo_record_page"))
    return files


def resolve_figshare(spec: dict[str, Any], timeout: int = 60) -> list[RemoteFile]:
    article_id = str(spec["article_id"])
    payload = get_json(f"https://api.figshare.com/v2/articles/{article_id}", timeout=timeout)
    return [
        RemoteFile(
            url=item["download_url"],
            name=safe_name(item.get("name") or url_filename(item["download_url"])),
            size=item.get("size"),
            checksum=("md5:" + item["computed_md5"]) if item.get("computed_md5") else None,
            source="figshare_api",
        )
        for item in payload.get("files", [])
        if item.get("download_url")
    ]


def recursive_objects(value: Any) -> Iterable[dict[str, Any]]:
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from recursive_objects(child)
    elif isinstance(value, list):
        for child in value:
            yield from recursive_objects(child)


def recursive_strings(value: Any) -> Iterable[str]:
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for child in value.values():
            yield from recursive_strings(child)
    elif isinstance(value, list):
        for child in value:
            yield from recursive_strings(child)


def resolve_biostudies(spec: dict[str, Any], timeout: int = 60) -> list[RemoteFile]:
    accession = str(spec["accession"])
    payload = get_json(f"https://www.ebi.ac.uk/biostudies/api/v1/studies/{accession}", timeout=timeout)
    manifest_url = spec.get("manifest_url")
    if isinstance(manifest_url, str):
        payload = [payload, get_json(manifest_url, timeout=timeout)]
    files: list[RemoteFile] = []
    seen: set[str] = set()
    for obj in recursive_objects(payload):
        path = obj.get("path") or obj.get("filePath")
        if not isinstance(path, str) or not path or path.endswith("/"):
            continue
        if path.startswith("https://"):
            url = path
        else:
            url = f"https://www.ebi.ac.uk/biostudies/files/{accession}/{urllib.parse.quote(path, safe='/')}"
        if url in seen or not is_direct_file_url(url):
            continue
        seen.add(url)
        size = obj.get("size") if isinstance(obj.get("size"), int) else None
        files.append(RemoteFile(url, safe_name(Path(path).name), size=size, source="biostudies_api"))
    return files


def resolve_tenx(spec: dict[str, Any], timeout: int = 60) -> list[RemoteFile]:
    page_url = str(spec["page_url"])
    body = get_bytes(page_url, timeout=timeout).decode("utf-8", errors="replace")
    files: list[RemoteFile] = []
    for url in extract_http_links(body):
        if "10xgenomics.com" in urllib.parse.urlsplit(url).netloc and is_direct_file_url(url):
            files.append(RemoteFile(url, url_filename(url), source="10x_dataset_page"))
    return files


def resolve_pennsieve(spec: dict[str, Any], timeout: int = 60) -> list[RemoteFile]:
    dataset_id = str(spec["dataset_id"])
    metadata = get_json(f"https://api.pennsieve.io/discover/datasets/{dataset_id}", timeout=timeout)
    uri = str(metadata.get("uri", ""))
    match = re.fullmatch(r"s3://([^/]+)/(.+)", uri)
    if not match:
        raise ValueError(f"Pennsieve dataset does not expose a public S3 URI: {uri!r}")
    bucket, prefix = match.groups()
    files: list[RemoteFile] = []
    continuation: str | None = None
    while True:
        query = {"list-type": "2", "prefix": prefix}
        if continuation:
            query["continuation-token"] = continuation
        listing_url = f"https://{bucket}.s3.amazonaws.com/?{urllib.parse.urlencode(query)}"
        root = ET.fromstring(get_bytes(listing_url, timeout=timeout))
        namespace = {"s3": "http://s3.amazonaws.com/doc/2006-03-01/"}
        for content in root.findall("s3:Contents", namespace):
            key = content.findtext("s3:Key", default="", namespaces=namespace)
            if not key or key.endswith("/"):
                continue
            size_text = content.findtext("s3:Size", default="", namespaces=namespace)
            url = f"https://{bucket}.s3.amazonaws.com/{urllib.parse.quote(key, safe='/')}"
            files.append(
                RemoteFile(
                    url=url,
                    name=safe_name(Path(key).name),
                    size=int(size_text) if size_text.isdigit() else None,
                    source="pennsieve_public_s3_listing",
                )
            )
        continuation = root.findtext("s3:NextContinuationToken", default="", namespaces=namespace) or None
        if not continuation:
            break
    return files


RESOLVERS = {
    "geo": resolve_geo,
    "zenodo": resolve_zenodo,
    "figshare": resolve_figshare,
    "biostudies": resolve_biostudies,
    "tenx": resolve_tenx,
    "pennsieve": resolve_pennsieve,
}


def resolve_asset(
    asset: dict[str, Any], offline: bool = False, timeout: int = 60, retries: int = 1
) -> tuple[list[RemoteFile], list[str]]:
    files = []
    direct_file_urls: set[str] = set()
    for item in asset.get("direct_files", []):
        url = item.get("url") if isinstance(item, dict) else None
        if not isinstance(url, str) or not is_direct_file_url(url):
            continue
        direct_file_urls.add(url)
        files.append(
            RemoteFile(
                url=url,
                name=url_filename(url),
                size=item.get("size") if isinstance(item.get("size"), int) else None,
                checksum=item.get("checksum") if isinstance(item.get("checksum"), str) else None,
                source="audited_direct_url",
            )
        )
    files.extend(
        RemoteFile(url=url, name=url_filename(url), source="audited_direct_url")
        for url in asset.get("direct_urls", [])
        if url not in direct_file_urls and is_direct_file_url(url)
    )
    errors: list[str] = []
    if not offline:
        for spec in asset.get("resolvers", []):
            resolver_type = spec.get("type")
            resolver = RESOLVERS.get(resolver_type)
            if resolver is None:
                errors.append(f"unsupported resolver: {resolver_type}")
                continue
            last_error: str | None = None
            resolved: list[RemoteFile] = []
            for attempt in range(retries + 1):
                try:
                    resolved = resolver(spec, timeout=timeout)
                    if resolved:
                        break
                    last_error = "resolver returned no downloadable files"
                except Exception as exc:  # keep the batch running and record the blocker
                    last_error = f"{type(exc).__name__}: {exc}"
                if attempt < retries:
                    time.sleep(min(2 ** attempt, 10))
            if not resolved and last_error:
                errors.append(f"{resolver_type}: {last_error}")
            files.extend(resolved)
    dedup: dict[str, RemoteFile] = {}
    for item in files:
        dedup.setdefault(item.url, item)
    return list(dedup.values()), errors


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_declared_checksum(path: Path, checksum: str | None) -> tuple[bool | None, str | None]:
    if not checksum or ":" not in checksum:
        return None, None
    algorithm, expected = checksum.split(":", 1)
    algorithm = algorithm.lower()
    if algorithm not in hashlib.algorithms_available:
        return None, None
    digest = hashlib.new(algorithm)
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    actual = digest.hexdigest()
    return actual.lower() == expected.lower(), actual


def download_one(
    item: dict[str, Any],
    *,
    output_root: Path,
    timeout: int,
    retries: int,
    overwrite: bool,
    extra_domains: list[str],
) -> dict[str, Any]:
    started = time.time()
    url = item["url"]
    destination = output_root / item["relative_path"]
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not allowed_url(url, extra_domains):
        return {**item, "status": "blocked_domain", "seconds": time.time() - started}
    expected_size = item.get("size")
    if destination.exists() and not overwrite:
        if expected_size is None or destination.stat().st_size == expected_size:
            return {
                **item,
                "status": "already_present",
                "bytes": destination.stat().st_size,
                "sha256": sha256_file(destination),
                "seconds": time.time() - started,
            }
    part = destination.with_name(destination.name + ".part")
    for attempt in range(retries + 1):
        try:
            offset = part.stat().st_size if part.exists() else 0
            headers = {"Range": f"bytes={offset}-"} if offset else {}
            with request(url, headers=headers, timeout=timeout) as response:
                final_url = response.geturl()
                if not allowed_url(final_url, extra_domains):
                    raise ValueError(f"redirect target is outside the domain allowlist: {final_url}")
                status = getattr(response, "status", 200)
                mode = "ab" if offset and status == 206 else "wb"
                if mode == "wb":
                    offset = 0
                with part.open(mode) as handle:
                    shutil.copyfileobj(response, handle, length=8 * 1024 * 1024)
            os.replace(part, destination)
            checksum_ok, actual_declared = verify_declared_checksum(destination, item.get("checksum"))
            return {
                **item,
                "status": "downloaded" if checksum_ok is not False else "checksum_mismatch",
                "bytes": destination.stat().st_size,
                "sha256": sha256_file(destination),
                "declared_checksum_actual": actual_declared,
                "seconds": time.time() - started,
            }
        except Exception as exc:
            if attempt >= retries:
                return {
                    **item,
                    "status": "failed",
                    "error": f"{type(exc).__name__}: {exc}",
                    "seconds": time.time() - started,
                }
            time.sleep(min(2 ** attempt, 30))
    raise AssertionError("unreachable")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output-root", type=Path, default=Path("xenium_ac_downloads"))
    parser.add_argument("--tiers", default="A,B,C", help="Comma-separated tier filter")
    parser.add_argument("--ranks", help="Comma-separated ranks and ranges, e.g. 1-10,14")
    parser.add_argument("--work-item", action="append", default=[])
    parser.add_argument("--include-alternates", action="store_true")
    parser.add_argument("--offline", action="store_true", help="Use audited direct URLs only")
    parser.add_argument("--max-workers", type=int, default=4)
    parser.add_argument("--resolve-workers", type=int, default=4)
    parser.add_argument("--max-files", type=int, default=0, help="0 means no file-count cap")
    parser.add_argument("--max-total-gb", type=float, default=0, help="0 means no known-size cap")
    parser.add_argument("--timeout", type=int, default=120)
    parser.add_argument("--retries", type=int, default=3)
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--allow-domain", action="append", default=[])
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--confirm-reviewed", help="Must equal manifest batch_id when --apply is used")
    return parser.parse_args()


def parse_ranks(text: str | None) -> set[int] | None:
    if not text:
        return None
    result: set[int] = set()
    for token in text.split(","):
        token = token.strip()
        if "-" in token:
            start, end = token.split("-", 1)
            result.update(range(int(start), int(end) + 1))
        else:
            result.add(int(token))
    return result


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def main() -> int:
    args = parse_args()
    bundle = args.bundle.resolve()
    manifest = json.loads((bundle / "manifest.json").read_text(encoding="utf-8"))
    batch_id = manifest["batch_id"]
    if args.apply and args.confirm_reviewed != batch_id:
        print(
            f"Refusing download: --confirm-reviewed must equal {batch_id!r}",
            file=sys.stderr,
        )
        return 2
    tiers = {x.strip().upper() for x in args.tiers.split(",") if x.strip()}
    ranks = parse_ranks(args.ranks)
    work_items = set(args.work_item)
    assets = load_jsonl(bundle / "data_assets.jsonl")
    selected = []
    for asset in assets:
        if asset.get("tier") not in tiers:
            continue
        if ranks is not None and int(asset.get("rank", 0)) not in ranks:
            continue
        if work_items and not work_items.intersection(asset.get("work_item_ids", [])):
            continue
        if not args.include_alternates and not asset.get("selected_by_default", False):
            continue
        selected.append(asset)

    plan: list[dict[str, Any]] = []
    resolver_errors: list[dict[str, Any]] = []
    seen_urls: set[str] = set()
    def resolve_selected(asset: dict[str, Any]):
        return asset, *resolve_asset(
            asset,
            offline=args.offline,
            timeout=args.timeout,
            retries=args.retries,
        )

    with concurrent.futures.ThreadPoolExecutor(
        max_workers=max(1, min(args.resolve_workers, len(selected) or 1))
    ) as resolve_executor:
        resolved_assets = list(resolve_executor.map(resolve_selected, selected))

    for asset, files, errors in resolved_assets:
        if errors:
            resolver_errors.append({"artifact_id": asset["artifact_id"], "errors": errors})
        base = f"tier_{asset['tier']}/rank_{int(asset['rank']):03d}_{safe_name(asset['paper_name'])}/{safe_name(asset['dataset_id'])}"
        for remote in files:
            if remote.url in seen_urls:
                continue
            seen_urls.add(remote.url)
            plan.append(
                {
                    **asdict(remote),
                    "artifact_id": asset["artifact_id"],
                    "dataset_id": asset["dataset_id"],
                    "paper_id": asset["paper_ids"][0],
                    "rank": asset["rank"],
                    "tier": asset["tier"],
                    "relative_path": f"{base}/{safe_name(remote.name)}",
                }
            )
    if args.max_files and len(plan) > args.max_files:
        plan = plan[: args.max_files]
    known_bytes = sum(int(item["size"]) for item in plan if item.get("size") is not None)
    if args.max_total_gb and known_bytes > args.max_total_gb * (1024 ** 3):
        print(
            f"Refusing plan: known size {known_bytes / (1024 ** 3):.2f} GiB exceeds --max-total-gb",
            file=sys.stderr,
        )
        return 2

    plan_record = {
        "batch_id": batch_id,
        "generated_at_epoch": time.time(),
        "dry_run": not args.apply,
        "selected_asset_groups": len(selected),
        "resolved_files": len(plan),
        "known_bytes": known_bytes,
        "unknown_size_files": sum(1 for item in plan if item.get("size") is None),
        "resolver_errors": resolver_errors,
        "files": plan,
    }
    args.output_root.mkdir(parents=True, exist_ok=True)
    plan_path = args.output_root / "download_plan.json"
    plan_path.write_text(json.dumps(plan_record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in plan_record.items() if k != "files"}, ensure_ascii=False, indent=2))
    print(f"Plan: {plan_path}")
    if not args.apply:
        print(f"Dry-run only. Review the plan, then use --apply --confirm-reviewed {batch_id}")
        return 0

    ledger_path = args.output_root / "download_results.jsonl"
    lock = threading.Lock()
    failures = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, args.max_workers)) as executor:
        futures = [
            executor.submit(
                download_one,
                item,
                output_root=args.output_root,
                timeout=args.timeout,
                retries=args.retries,
                overwrite=args.overwrite,
                extra_domains=args.allow_domain,
            )
            for item in plan
        ]
        with ledger_path.open("a", encoding="utf-8") as ledger:
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                if result["status"] in {"failed", "blocked_domain", "checksum_mismatch"}:
                    failures += 1
                with lock:
                    ledger.write(json.dumps(result, ensure_ascii=False) + "\n")
                    ledger.flush()
                print(f"{result['status']}: {result['relative_path']}")
    print(f"Download ledger: {ledger_path}; failures={failures}")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
