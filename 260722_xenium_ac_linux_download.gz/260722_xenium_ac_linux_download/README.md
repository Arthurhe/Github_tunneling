# Xenium A–C 级数据 Linux 批量下载包

批次：`xenium_ac_20260722`。来源为 Xenium `0.3.0` 初步排序前 24 篇（A=10、B=6、C=8）及其逐篇 L2 dataset observations。

本包包含 24 篇论文、68 个规范化 dataset identity、69 个 data-asset observation。其中 31 个公开主 Xenium 资产组默认纳入；其余 38 个配对、补充、替代或非公开记录只保留关系，除非显式加入。

## 安全模型

- Python 3.9+，仅用标准库；默认只生成 `download_plan.json`，不下载。
- 真正下载必须同时提供 `--apply --confirm-reviewed xenium_ac_20260722`。
- 只接受 HTTPS 与内置域名白名单；支持断点续传、重试、并发、已知 checksum 校验，并为每个完成文件记录 SHA-256。
- 本包不含凭据，不绕过登录、验证码、许可或受控访问。下载结果与 ledger 应留在下游服务器，不回写本项目 registry。

## 推荐运行顺序

```bash
cd 260722_xenium_ac_linux_download

# 1. 联网解析 repository manifest，但只生成计划
python3 download_xenium_ac.py --output-root /data/xenium_ac

# 2. 先下载 A 级（排名 1–10）；建议同时给出容量上限
python3 download_xenium_ac.py --tiers A --ranks 1-10 \
  --output-root /data/xenium_ac --max-workers 4 --max-total-gb 2000 \
  --apply --confirm-reviewed xenium_ac_20260722

# 3. 审阅后继续 B、C
python3 download_xenium_ac.py --tiers B,C \
  --output-root /data/xenium_ac --max-workers 4 \
  --apply --confirm-reviewed xenium_ac_20260722
```

`--offline` 仅使用审计时已经记录的直链；`--include-alternates` 会加入配对 scRNA/bulk/Visium、补充文件等非默认记录。可用 `--work-item awi_...` 或 `--ranks 3,5-8` 精确选择。未知文件大小不计入 `--max-total-gb`，因此执行前仍须人工检查计划。

## 输出

- `download_plan.json`：当次解析后的逐文件 URL、路径、已知大小、resolver error/warning、deferred asset 与修复动作。
- `download_plan.history/`：同目录续跑时自动保留的旧计划快照。
- `download_results.jsonl`：实际下载 ledger；含状态、字节数、SHA-256、耗时和错误。
- 目录按 `tier/rank/paper/dataset` 组织。共享 dataset URL 在同一次执行中只下载一次。

## 同目录安全续跑

- 不使用 `--overwrite` 时，已有文件会先核对远端/manifest 大小、checksum、归档结构或新版验证 receipt；通过后记为 `already_present_verified`，不会重复下载。
- 大小不符、checksum 错误或 TAR/ZIP/GZip 结构损坏的正式文件会被删除并重新下载；新文件只在 `.part` 验收通过后原子改为正式文件名。
- 如果既没有远端大小/checksum、也不是可检查归档且没有新版验证 receipt，已有文件保留不删并标记 `existing_unverifiable`；脚本返回失败，避免把可能正确的文件误删。
- 旧版 ledger 中不同 URL 共用同一目标路径的文件会列入 `repair_actions`；dry-run 只报告，带 `--apply` 后才删除这些已知碰撞文件。
- 如果旧碰撞路径也是当前计划中的唯一合法目标，脚本会删除旧副本并立即按当前 URL 重下；成功修复会形成 ledger checkpoint，后续续跑不再重复清理。
- 通用 HTML 导航页、订阅页和营销页会被排除并清理；Xenium 输出中的 `analysis_summary.html` 作为合法质控报告保留。
- 计划中只要仍存在不同 URL 指向同一 `relative_path`，脚本就以非零状态中止，绝不开始下载。
- artifact 已经通过直链或备用 resolver 获得文件时，其他辅助 resolver 的空结果只记入 `resolver_warnings`，不阻塞下载。
- 已知 restricted/403 且没有公开文件的资产记入 `deferred_assets`，默认不阻塞其他可下载资产；使用 `--require-all-assets` 时才把 deferred 视为致命错误。
- 只有预期公开却没有任何 locator 成功时才进入 `resolver_errors` 并返回非零状态。

## 已知边界

GEO、Zenodo、Figshare、BioStudies、10x dataset page 和 Pennsieve 使用公开 API/manifest 动态解析。远端页面结构、record version、文件名和许可可能变化；plan 是执行时快照。大型 archive 内部成员与格式完整性不在本脚本中验证，应由 Xenium 下游 ingestion pipeline 继续审计。

截至本批次生成时，Zenodo `17285218` 是“record 公开、files restricted”，脚本只报告 blocker，不会绕过访问控制。肾病 atlas 的旧记录 `18674907` 文件受限，但同一 observation 已包含开放新版 `19868428`，下载计划会使用开放新版文件并保留旧版 blocker。
