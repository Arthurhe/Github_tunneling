#!/usr/bin/env python3
"""Resolve and download a reviewed Xenium handoff bundle on Linux.

The script uses only the Python standard library.  It is dry-run by default;
downloads require both --apply and --confirm-reviewed <batch_id>.
"""

from __future__ import annotations

import argparse
import bz2
import concurrent.futures
import gzip
import hashlib
import html
import json
import lzma
import os
import re
import shutil
import sys
import tarfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path, PurePosixPath
from typing import Any, Iterable, Optional


USER_AGENT = "ScientificLiteratureIntake-XeniumDownloader/2.0"
DEFAULT_ALLOWED_SUFFIXES = {
    "10xgenomics.com",
    "amazonaws.com",
    "biostudies.org",
    "ebi.ac.uk",
    "figshare.com",
    "ftp.ncbi.nlm.nih.gov",
    "huggingface.co",
    "ncbi.nlm.nih.gov",
    "pennsieve.io",
    "springernature.com",
    "static-content.springer.com",
    "zenodo.org",
}
DIRECT_EXTENSIONS = {
    ".7z", ".bz2", ".csv", ".gz", ".h5", ".h5ad", ".json",
    ".loom", ".mtx", ".parquet", ".rds", ".tar", ".tif", ".tiff",
    ".tsv", ".txt", ".xlsx", ".xml", ".xz", ".zarr", ".zip",
}
INTEGRITY_VALIDATION_VERSION = 2


@dataclass(frozen=True)
class RemoteFile:
    url: str
    name: str
    size: Optional[int] = None
    checksum: Optional[str] = None
    source: str = "manifest"
    relative_path: Optional[str] = None


def request(
    url: str,
    *,
    headers: Optional[dict[str, str]] = None,
    timeout: int = 60,
    method: Optional[str] = None,
):
    merged = {"User-Agent": USER_AGENT, "Accept": "*/*"}
    if headers:
        merged.update(headers)
    return urllib.request.urlopen(
        urllib.request.Request(url, headers=merged, method=method),
        timeout=timeout,
    )


def get_bytes(url: str, timeout: int = 60) -> bytes:
    with request(url, timeout=timeout) as response:
        return response.read()


def get_json(url: str, timeout: int = 60) -> Any:
    return json.loads(get_bytes(url, timeout=timeout).decode("utf-8"))


def safe_name(value: str, fallback: str = "download") -> str:
    value = urllib.parse.unquote(value).strip().replace("\\", "_").replace("/", "_")
    value = re.sub(r"[^A-Za-z0-9._+()=-]+", "_", value).strip("._")
    return value[:220] or fallback


def safe_relative_path(value: str, fallback: str = "download") -> str:
    normalized = urllib.parse.unquote(value).replace("\\", "/").strip()
    path = PurePosixPath(normalized)
    if path.is_absolute() or any(part == ".." for part in path.parts):
        raise ValueError(f"Unsafe repository-relative path: {value!r}")
    parts = [safe_name(part) for part in path.parts if part not in {"", "."}]
    return "/".join(parts) if parts else safe_name(fallback)


def url_filename(url: str) -> str:
    path = urllib.parse.urlsplit(url).path.rstrip("/")
    return safe_name(Path(path).name or "download")


def is_direct_file_url(url: str) -> bool:
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != "https":
        return False
    if "download=true" in parsed.query.lower():
        return True
    lower = parsed.path.lower()
    return any(lower.endswith(ext) or f"{ext}." in lower for ext in DIRECT_EXTENSIONS)


def allowed_url(url: str, extra_suffixes: Iterable[str] = ()) -> bool:
    parsed = urllib.parse.urlsplit(url)
    host = (parsed.hostname or "").lower().rstrip(".")
    if parsed.scheme != "https" or not host:
        return False
    allowed = DEFAULT_ALLOWED_SUFFIXES | {x.lower().lstrip(".") for x in extra_suffixes}
    return any(host == suffix or host.endswith("." + suffix) for suffix in allowed)


def extract_http_links(text: str) -> list[str]:
    text = html.unescape(text.replace("\\/", "/"))
    links = re.findall(r"https://[^\s\"'<>\\]+", text)
    return sorted({link.rstrip("),.;") for link in links})


def list_http_directory(
    url: str, timeout: int = 60, relative_prefix: Optional[str] = None
) -> list[RemoteFile]:
    body = get_bytes(url, timeout=timeout).decode("utf-8", errors="replace")
    found: list[RemoteFile] = []
    base = urllib.parse.urlsplit(url)
    base_path = base.path.rstrip("/") + "/"
    for href in re.findall(r"href=[\"']([^\"']+)[\"']", body, flags=re.IGNORECASE):
        href = html.unescape(href)
        if href.startswith("?") or href in {"../", "./"} or href.endswith("/"):
            continue
        resolved = urllib.parse.urljoin(url, href)
        candidate = urllib.parse.urlsplit(resolved)
        if (
            candidate.hostname != base.hostname
            or not candidate.path.startswith(base_path)
            or not is_direct_file_url(resolved)
        ):
            continue
        name = url_filename(resolved)
        relative_path = f"{relative_prefix}/{name}" if relative_prefix else name
        found.append(
            RemoteFile(
                resolved,
                name,
                source="directory_listing",
                relative_path=safe_relative_path(relative_path),
            )
        )
    return found


def geo_bucket(accession: str) -> str:
    match = re.fullmatch(r"(GS[EM])(\d+)", accession.upper())
    if not match:
        raise ValueError(f"Unsupported GEO accession: {accession}")
    prefix, digits = match.groups()
    return f"{prefix}{digits[:-3]}nnn" if len(digits) > 3 else f"{prefix}nnn"


def resolve_geo(spec: dict[str, Any], timeout: int = 60) -> list[RemoteFile]:
    accession = str(spec["accession"]).upper()
    accessions = [accession]
    if accession.startswith("GSE"):
        soft_url = (
            "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?"
            + urllib.parse.urlencode({"acc": accession, "targ": "self", "form": "text", "view": "full"})
        )
        text = get_bytes(soft_url, timeout=timeout).decode("utf-8", errors="replace")
        accessions.extend(sorted(set(re.findall(r"\bGSM\d+\b", text))))
    directories = []
    for acc in accessions:
        kind = "series" if acc.startswith("GSE") else "samples"
        directories.append(
            (acc, f"https://ftp.ncbi.nlm.nih.gov/geo/{kind}/{geo_bucket(acc)}/{acc}/suppl/")
        )

    def safe_listing(item: tuple[str, str]) -> list[RemoteFile]:
        acc, directory = item
        try:
            return list_http_directory(directory, timeout=timeout, relative_prefix=acc)
        except (urllib.error.HTTPError, urllib.error.URLError):
            return []

    files: list[RemoteFile] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(4, len(directories))) as executor:
        for listing in executor.map(safe_listing, directories):
            files.extend(listing)
    return files


def resolve_zenodo(spec: dict[str, Any], timeout: int = 60) -> list[RemoteFile]:
    record_id = str(spec["record_id"])
    files: list[RemoteFile] = []
    try:
        payload = get_json(f"https://zenodo.org/api/records/{record_id}", timeout=timeout)
        for item in payload.get("files", []):
            links = item.get("links", {})
            url = links.get("content") or links.get("self")
            if not url:
                continue
            files.append(
                RemoteFile(
                    url=url,
                    name=safe_name(item.get("key") or url_filename(url)),
                    size=item.get("size"),
                    checksum=item.get("checksum"),
                    source="zenodo_api",
                    relative_path=safe_relative_path(item.get("key") or url_filename(url)),
                )
            )
    except urllib.error.HTTPError as exc:
        if exc.code not in {401, 403}:
            raise
    if not files:
        page_url = f"https://zenodo.org/records/{record_id}"
        body = get_bytes(page_url, timeout=timeout).decode("utf-8", errors="replace")
        for href in re.findall(r"href=[\"']([^\"']*?/files/[^\"']+)[\"']", body, flags=re.IGNORECASE):
            url = urllib.parse.urljoin(page_url, html.unescape(href))
            if is_direct_file_url(url):
                name = url_filename(url)
                files.append(
                    RemoteFile(url, name, source="zenodo_record_page", relative_path=name)
                )
    return files


def resolve_figshare(spec: dict[str, Any], timeout: int = 60) -> list[RemoteFile]:
    article_id = str(spec["article_id"])
    payload = get_json(f"https://api.figshare.com/v2/articles/{article_id}", timeout=timeout)
    return [
        RemoteFile(
            url=item["download_url"],
            name=safe_name(item.get("name") or url_filename(item["download_url"])),
            size=item.get("size"),
            checksum=("md5:" + item["computed_md5"]) if item.get("computed_md5") else None,
            source="figshare_api",
            relative_path=safe_relative_path(item.get("name") or url_filename(item["download_url"])),
        )
        for item in payload.get("files", [])
        if item.get("download_url")
    ]


def recursive_objects(value: Any) -> Iterable[dict[str, Any]]:
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from recursive_objects(child)
    elif isinstance(value, list):
        for child in value:
            yield from recursive_objects(child)


def recursive_strings(value: Any) -> Iterable[str]:
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for child in value.values():
            yield from recursive_strings(child)
    elif isinstance(value, list):
        for child in value:
            yield from recursive_strings(child)


def resolve_biostudies(spec: dict[str, Any], timeout: int = 60) -> list[RemoteFile]:
    accession = str(spec["accession"])
    payload = get_json(f"https://www.ebi.ac.uk/biostudies/api/v1/studies/{accession}", timeout=timeout)
    manifest_url = spec.get("manifest_url")
    if isinstance(manifest_url, str):
        payload = [payload, get_json(manifest_url, timeout=timeout)]
    files: list[RemoteFile] = []
    seen: set[str] = set()
    for obj in recursive_objects(payload):
        path = obj.get("path") or obj.get("filePath")
        if not isinstance(path, str) or not path or path.endswith("/"):
            continue
        if path.startswith("https://"):
            url = path
        else:
            url = f"https://www.ebi.ac.uk/biostudies/files/{accession}/{urllib.parse.quote(path, safe='/')}"
        if url in seen or not is_direct_file_url(url):
            continue
        seen.add(url)
        size = obj.get("size") if isinstance(obj.get("size"), int) else None
        files.append(
            RemoteFile(
                url,
                safe_name(Path(path).name),
                size=size,
                source="biostudies_api",
                relative_path=safe_relative_path(path),
            )
        )
    return files


def resolve_tenx(spec: dict[str, Any], timeout: int = 60) -> list[RemoteFile]:
    page_url = str(spec["page_url"])
    body = get_bytes(page_url, timeout=timeout).decode("utf-8", errors="replace")
    files: list[RemoteFile] = []
    for url in extract_http_links(body):
        if "10xgenomics.com" in urllib.parse.urlsplit(url).netloc and is_direct_file_url(url):
            name = url_filename(url)
            files.append(RemoteFile(url, name, source="10x_dataset_page", relative_path=name))
    return files


def resolve_pennsieve(spec: dict[str, Any], timeout: int = 60) -> list[RemoteFile]:
    dataset_id = str(spec["dataset_id"])
    metadata = get_json(f"https://api.pennsieve.io/discover/datasets/{dataset_id}", timeout=timeout)
    uri = str(metadata.get("uri", ""))
    match = re.fullmatch(r"s3://([^/]+)/(.+)", uri)
    if not match:
        raise ValueError(f"Pennsieve dataset does not expose a public S3 URI: {uri!r}")
    bucket, prefix = match.groups()
    files: list[RemoteFile] = []
    continuation: Optional[str] = None
    while True:
        query = {"list-type": "2", "prefix": prefix}
        if continuation:
            query["continuation-token"] = continuation
        listing_url = f"https://{bucket}.s3.amazonaws.com/?{urllib.parse.urlencode(query)}"
        root = ET.fromstring(get_bytes(listing_url, timeout=timeout))
        namespace = {"s3": "http://s3.amazonaws.com/doc/2006-03-01/"}
        for content in root.findall("s3:Contents", namespace):
            key = content.findtext("s3:Key", default="", namespaces=namespace)
            if not key or key.endswith("/"):
                continue
            size_text = content.findtext("s3:Size", default="", namespaces=namespace)
            url = f"https://{bucket}.s3.amazonaws.com/{urllib.parse.quote(key, safe='/')}"
            normalized_prefix = prefix.strip("/")
            normalized_key = key.lstrip("/")
            if normalized_key == normalized_prefix:
                continue
            if not normalized_key.startswith(normalized_prefix + "/"):
                raise ValueError(f"Pennsieve S3 key is outside dataset prefix: {key!r}")
            repository_path = normalized_key[len(normalized_prefix) + 1 :]
            files.append(
                RemoteFile(
                    url=url,
                    name=safe_name(Path(key).name),
                    size=int(size_text) if size_text.isdigit() else None,
                    source="pennsieve_public_s3_listing",
                    relative_path=safe_relative_path(repository_path),
                )
            )
        continuation = root.findtext("s3:NextContinuationToken", default="", namespaces=namespace) or None
        if not continuation:
            break
    return files


RESOLVERS = {
    "geo": resolve_geo,
    "zenodo": resolve_zenodo,
    "figshare": resolve_figshare,
    "biostudies": resolve_biostudies,
    "tenx": resolve_tenx,
    "pennsieve": resolve_pennsieve,
}


def resolve_asset(
    asset: dict[str, Any], offline: bool = False, timeout: int = 60, retries: int = 1
) -> tuple[list[RemoteFile], list[str]]:
    files = []
    direct_file_urls: set[str] = set()
    for item in asset.get("direct_files", []):
        url = item.get("url") if isinstance(item, dict) else None
        if not isinstance(url, str) or not is_direct_file_url(url):
            continue
        direct_file_urls.add(url)
        files.append(
            RemoteFile(
                url=url,
                name=url_filename(url),
                size=item.get("size") if isinstance(item.get("size"), int) else None,
                checksum=item.get("checksum") if isinstance(item.get("checksum"), str) else None,
                source="audited_direct_url",
            )
        )
    files.extend(
        RemoteFile(url=url, name=url_filename(url), source="audited_direct_url")
        for url in asset.get("direct_urls", [])
        if url not in direct_file_urls and is_direct_file_url(url)
    )
    errors: list[str] = []
    if not offline:
        for spec in asset.get("resolvers", []):
            resolver_type = spec.get("type")
            resolver = RESOLVERS.get(resolver_type)
            if resolver is None:
                errors.append(f"unsupported resolver: {resolver_type}")
                continue
            last_error: Optional[str] = None
            resolved: list[RemoteFile] = []
            for attempt in range(retries + 1):
                try:
                    resolved = resolver(spec, timeout=timeout)
                    if resolved:
                        break
                    last_error = "resolver returned no downloadable files"
                except Exception as exc:  # keep the batch running and record the blocker
                    last_error = f"{type(exc).__name__}: {exc}"
                if attempt < retries:
                    time.sleep(min(2 ** attempt, 10))
            if not resolved and last_error:
                errors.append(f"{resolver_type}: {last_error}")
            files.extend(resolved)
    dedup: dict[str, RemoteFile] = {}
    for item in files:
        previous = dedup.get(item.url)
        if previous is None:
            dedup[item.url] = item
            continue
        if item.relative_path and not previous.relative_path:
            dedup[item.url] = RemoteFile(
                url=item.url,
                name=item.name,
                size=item.size if item.size is not None else previous.size,
                checksum=item.checksum or previous.checksum,
                source=item.source,
                relative_path=item.relative_path,
            )
    return list(dedup.values()), errors


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_declared_checksum(
    path: Path, checksum: Optional[str]
) -> tuple[Optional[bool], Optional[str]]:
    if not checksum or ":" not in checksum:
        return None, None
    algorithm, expected = checksum.split(":", 1)
    algorithm = algorithm.lower()
    if algorithm not in hashlib.algorithms_available:
        return None, None
    digest = hashlib.new(algorithm)
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    actual = digest.hexdigest()
    return actual.lower() == expected.lower(), actual


class IntegrityError(RuntimeError):
    pass


def _drain(handle) -> None:
    while handle.read(8 * 1024 * 1024):
        pass


def archive_name_supported(name: str) -> bool:
    lower = name.lower()
    return lower.endswith(
        (
            ".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2", ".tar.xz", ".txz",
            ".zip", ".gz", ".bz2", ".xz",
        )
    )


def verify_archive(
    path: Path, logical_name: Optional[str] = None
) -> tuple[Optional[bool], Optional[str]]:
    lower = (logical_name or path.name).lower()
    try:
        if lower.endswith((".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2", ".tar.xz", ".txz")):
            with tarfile.open(path, "r:*") as archive:
                for member in archive:
                    if not member.isfile():
                        continue
                    extracted = archive.extractfile(member)
                    if extracted is not None:
                        with extracted:
                            _drain(extracted)
            return True, None
        if lower.endswith(".zip"):
            with zipfile.ZipFile(path) as archive:
                bad_member = archive.testzip()
                if bad_member:
                    return False, f"zip CRC failed for member {bad_member!r}"
            return True, None
        if lower.endswith(".gz"):
            with gzip.open(path, "rb") as handle:
                _drain(handle)
            return True, None
        if lower.endswith(".bz2"):
            with bz2.open(path, "rb") as handle:
                _drain(handle)
            return True, None
        if lower.endswith(".xz"):
            with lzma.open(path, "rb") as handle:
                _drain(handle)
            return True, None
    except (OSError, EOFError, tarfile.TarError, zipfile.BadZipFile) as exc:
        return False, f"{type(exc).__name__}: {exc}"
    return None, None


def response_total_size(response, status: int, offset: int) -> Optional[int]:
    content_range = response.headers.get("Content-Range")
    if status == 206:
        match = re.fullmatch(r"bytes\s+(\d+)-(\d+)/(\d+|\*)", content_range or "")
        if not match:
            raise IntegrityError("206 response is missing a valid Content-Range header")
        start, end, total = match.groups()
        if int(start) != offset or int(end) < int(start):
            raise IntegrityError(
                f"Content-Range does not resume at byte {offset}: {content_range!r}"
            )
        return None if total == "*" else int(total)
    length = response.headers.get("Content-Length")
    return int(length) if length and length.isdigit() else None


def probe_remote_size(
    url: str, *, timeout: int, extra_domains: list[str]
) -> Optional[int]:
    for method, headers in (("HEAD", {}), ("GET", {"Range": "bytes=0-0"})):
        try:
            with request(url, headers=headers, timeout=timeout, method=method) as response:
                if not allowed_url(response.geturl(), extra_domains):
                    return None
                status = getattr(response, "status", 200)
                if status == 206:
                    return response_total_size(response, status, 0)
                length = response.headers.get("Content-Length")
                if length and length.isdigit():
                    return int(length)
        except (OSError, ValueError, urllib.error.HTTPError, urllib.error.URLError):
            continue
    return None


def verify_file(
    path: Path,
    *,
    expected_size: Optional[int],
    checksum: Optional[str],
    prior_result: Optional[dict[str, Any]] = None,
    logical_name: Optional[str] = None,
) -> tuple[bool, str, dict[str, Any]]:
    actual_size = path.stat().st_size
    details: dict[str, Any] = {
        "validation_version": INTEGRITY_VALIDATION_VERSION,
        "actual_size": actual_size,
        "expected_size": expected_size,
        "size_verified": False,
        "checksum_verified": False,
        "archive_verified": False,
        "prior_receipt_verified": False,
        "integrity_verified": False,
    }
    evidence = 0
    if expected_size is not None:
        evidence += 1
        details["size_verified"] = actual_size == expected_size
        if actual_size != expected_size:
            return False, f"size mismatch: expected {expected_size}, got {actual_size}", details

    checksum_ok, actual_declared = verify_declared_checksum(path, checksum)
    details["declared_checksum_actual"] = actual_declared
    if checksum_ok is not None:
        evidence += 1
        details["checksum_verified"] = checksum_ok
        if not checksum_ok:
            return False, "declared checksum mismatch", details

    prior_validation = prior_result.get("validation", {}) if prior_result else {}
    if (
        prior_result
        and prior_result.get("validation", {}).get("validation_version")
        == INTEGRITY_VALIDATION_VERSION
        and prior_result.get("validation", {}).get("integrity_verified") is True
        and isinstance(prior_result.get("bytes"), int)
        and isinstance(prior_result.get("sha256"), str)
    ):
        if actual_size != prior_result["bytes"]:
            return False, "file size differs from prior verified receipt", details
        details["prior_receipt_verified"] = sha256_file(path) == prior_result["sha256"]
        evidence += 1
        if not details["prior_receipt_verified"]:
            return False, "SHA-256 differs from prior verified receipt", details

    archive_name = logical_name or path.name
    if (
        archive_name_supported(archive_name)
        and details["prior_receipt_verified"]
        and prior_validation.get("archive_verified") is True
    ):
        details["archive_verified"] = True
        evidence += 1
    else:
        archive_ok, archive_error = verify_archive(path, logical_name=logical_name)
        if archive_ok is not None:
            evidence += 1
            details["archive_verified"] = archive_ok
            if not archive_ok:
                return False, f"archive integrity failure: {archive_error}", details

    if evidence == 0:
        return False, "no size, checksum, archive, or verified prior receipt", details
    details["integrity_verified"] = True
    return True, "verified", details


def output_path(output_root: Path, relative_path: str) -> Path:
    safe_relative = safe_relative_path(relative_path)
    root = output_root.resolve()
    target = (root / Path(*PurePosixPath(safe_relative).parts)).resolve()
    try:
        target.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"Target path escapes output root: {relative_path!r}") from exc
    return target


def download_one(
    item: dict[str, Any],
    *,
    output_root: Path,
    timeout: int,
    retries: int,
    overwrite: bool,
    extra_domains: list[str],
    prior_result: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    started = time.time()
    url = item["url"]
    destination = output_path(output_root, item["relative_path"])
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not allowed_url(url, extra_domains):
        return {**item, "status": "blocked_domain", "seconds": time.time() - started}
    expected_size = item.get("size")
    prior_is_verified = bool(
        prior_result
        and prior_result.get("validation", {}).get("validation_version")
        == INTEGRITY_VALIDATION_VERSION
        and prior_result.get("validation", {}).get("integrity_verified") is True
    )
    if (
        expected_size is None
        and destination.exists()
        and not overwrite
        and not prior_is_verified
    ):
        expected_size = probe_remote_size(
            url, timeout=timeout, extra_domains=extra_domains
        )
    repaired_existing = False
    repair_reason = None
    if destination.exists() and not overwrite:
        valid, reason, validation = verify_file(
            destination,
            expected_size=expected_size,
            checksum=item.get("checksum"),
            prior_result=prior_result,
        )
        if valid:
            return {
                **item,
                "status": "already_present_verified",
                "bytes": destination.stat().st_size,
                "sha256": sha256_file(destination),
                "validation": validation,
                "seconds": time.time() - started,
            }
        if reason == "no size, checksum, archive, or verified prior receipt":
            return {
                **item,
                "status": "existing_unverifiable",
                "bytes": destination.stat().st_size,
                "validation": validation,
                "error": reason,
                "seconds": time.time() - started,
            }
        destination.unlink()
        repaired_existing = True
        repair_reason = reason
    part = destination.with_name(destination.name + ".part")
    if expected_size is not None and part.exists() and part.stat().st_size > expected_size:
        part.unlink()
    for attempt in range(retries + 1):
        try:
            offset = part.stat().st_size if part.exists() else 0
            headers = {"Range": f"bytes={offset}-"} if offset else {}
            with request(url, headers=headers, timeout=timeout) as response:
                final_url = response.geturl()
                if not allowed_url(final_url, extra_domains):
                    raise ValueError(f"redirect target is outside the domain allowlist: {final_url}")
                status = getattr(response, "status", 200)
                response_size = response_total_size(response, status, offset)
                if expected_size is not None and response_size is not None and expected_size != response_size:
                    raise IntegrityError(
                        f"manifest size {expected_size} disagrees with remote size {response_size}"
                    )
                expected_total = expected_size if expected_size is not None else response_size
                mode = "ab" if offset and status == 206 else "wb"
                if mode == "wb":
                    offset = 0
                with part.open(mode) as handle:
                    shutil.copyfileobj(response, handle, length=8 * 1024 * 1024)
                    handle.flush()
                    os.fsync(handle.fileno())
            valid, reason, validation = verify_file(
                part,
                expected_size=expected_total,
                checksum=item.get("checksum"),
                prior_result=None,
                logical_name=destination.name,
            )
            if not valid:
                raise IntegrityError(reason)
            sha256 = sha256_file(part)
            bytes_downloaded = part.stat().st_size
            os.replace(part, destination)
            return {
                **item,
                "status": "repaired_and_downloaded" if repaired_existing else "downloaded",
                "bytes": bytes_downloaded,
                "sha256": sha256,
                "validation": validation,
                "repaired_existing": repaired_existing,
                "repair_reason": repair_reason,
                "seconds": time.time() - started,
            }
        except Exception as exc:
            if isinstance(exc, IntegrityError) and part.exists():
                part.unlink()
            if attempt >= retries:
                return {
                    **item,
                    "status": "failed",
                    "error": f"{type(exc).__name__}: {exc}",
                    "repaired_existing": repaired_existing,
                    "repair_reason": repair_reason,
                    "seconds": time.time() - started,
                }
            time.sleep(min(2 ** attempt, 30))
    raise AssertionError("unreachable")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output-root", type=Path, default=Path("xenium_ac_downloads"))
    parser.add_argument("--tiers", default="A,B,C", help="Comma-separated tier filter")
    parser.add_argument("--ranks", help="Comma-separated ranks and ranges, e.g. 1-10,14")
    parser.add_argument("--work-item", action="append", default=[])
    parser.add_argument("--include-alternates", action="store_true")
    parser.add_argument("--offline", action="store_true", help="Use audited direct URLs only")
    parser.add_argument("--max-workers", type=int, default=4)
    parser.add_argument("--resolve-workers", type=int, default=4)
    parser.add_argument("--max-files", type=int, default=0, help="0 means no file-count cap")
    parser.add_argument("--max-total-gb", type=float, default=0, help="0 means no known-size cap")
    parser.add_argument("--timeout", type=int, default=120)
    parser.add_argument("--retries", type=int, default=3)
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--allow-domain", action="append", default=[])
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--confirm-reviewed", help="Must equal manifest batch_id when --apply is used")
    return parser.parse_args()


def parse_ranks(text: Optional[str]) -> Optional[set[int]]:
    if not text:
        return None
    result: set[int] = set()
    for token in text.split(","):
        token = token.strip()
        if "-" in token:
            start, end = token.split("-", 1)
            result.update(range(int(start), int(end) + 1))
        else:
            result.add(int(token))
    return result


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def load_download_ledger(
    path: Path, extra_domains: list[str]
) -> tuple[dict[str, dict[str, Any]], list[dict[str, Any]]]:
    latest: dict[str, dict[str, Any]] = {}
    urls_by_path: dict[str, set[str]] = {}
    unsafe_paths: set[str] = set()
    if not path.exists():
        return latest, []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        relative_path = record.get("relative_path")
        url = record.get("url")
        if not isinstance(relative_path, str):
            continue
        latest[relative_path] = record
        if isinstance(url, str):
            urls_by_path.setdefault(relative_path, set()).add(url)
            if (
                urllib.parse.urlsplit(url).path.lower().endswith((".html", ".htm"))
                or not allowed_url(url, extra_domains)
            ):
                unsafe_paths.add(relative_path)
    actions: list[dict[str, Any]] = []
    for relative_path, urls in sorted(urls_by_path.items()):
        if len(urls) > 1:
            actions.append(
                {
                    "action": "delete_legacy_collision_path",
                    "relative_path": relative_path,
                    "reason": f"legacy ledger maps {len(urls)} URLs to one target",
                }
            )
    for relative_path in sorted(unsafe_paths):
        actions.append(
            {
                "action": "delete_unsafe_link_output",
                "relative_path": relative_path,
                "reason": "legacy output came from an HTML or disallowed-domain URL",
            }
        )
    return latest, actions


def deduplicate_repair_actions(actions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    dedup: dict[str, dict[str, Any]] = {}
    for action in actions:
        relative_path = action["relative_path"]
        if relative_path in dedup:
            dedup[relative_path]["reason"] += "; " + action["reason"]
        else:
            dedup[relative_path] = dict(action)
    return [dedup[key] for key in sorted(dedup)]


def perform_repair_actions(
    output_root: Path,
    actions: list[dict[str, Any]],
    active_paths: set[str],
) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    for action in actions:
        relative_path = action["relative_path"]
        if relative_path in active_paths:
            results.append(
                {
                    **action,
                    "status": "repair_blocked_active_target",
                }
            )
            continue
        target = output_path(output_root, relative_path)
        removed: list[str] = []
        for candidate in (target, target.with_name(target.name + ".part")):
            if candidate.is_file() or candidate.is_symlink():
                candidate.unlink()
                removed.append(str(candidate))
        results.append(
            {
                **action,
                "status": "removed_legacy_invalid" if removed else "not_present",
                "removed": removed,
            }
        )
    return results


def write_plan_preserving_previous(path: Path, plan_record: dict[str, Any]) -> None:
    rendered = json.dumps(plan_record, ensure_ascii=False, indent=2) + "\n"
    if path.exists():
        previous = path.read_bytes()
        previous_hash = hashlib.sha256(previous).hexdigest()[:16]
        history = path.parent / "download_plan.history"
        history.mkdir(parents=True, exist_ok=True)
        history_path = history / f"download_plan_{previous_hash}.json"
        if not history_path.exists():
            history_path.write_bytes(previous)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(rendered, encoding="utf-8")
    os.replace(temporary, path)


def asset_base_path(asset: dict[str, Any]) -> str:
    return (
        f"tier_{asset['tier']}/"
        f"rank_{int(asset['rank']):03d}_{safe_name(asset['paper_name'])}/"
        f"{safe_name(asset['dataset_id'])}"
    )


def repair_actions_for_selected(
    actions: list[dict[str, Any]], selected_prefixes: set[str]
) -> list[dict[str, Any]]:
    return [
        action
        for action in actions
        if any(action["relative_path"].startswith(prefix) for prefix in selected_prefixes)
    ]


def main() -> int:
    args = parse_args()
    bundle = args.bundle.resolve()
    args.output_root = args.output_root.resolve()
    args.output_root.mkdir(parents=True, exist_ok=True)
    ledger_path = args.output_root / "download_results.jsonl"
    prior_results, ledger_repair_actions = load_download_ledger(
        ledger_path, args.allow_domain
    )
    manifest = json.loads((bundle / "manifest.json").read_text(encoding="utf-8"))
    batch_id = manifest["batch_id"]
    if args.apply and args.confirm_reviewed != batch_id:
        print(
            f"Refusing download: --confirm-reviewed must equal {batch_id!r}",
            file=sys.stderr,
        )
        return 2
    tiers = {x.strip().upper() for x in args.tiers.split(",") if x.strip()}
    ranks = parse_ranks(args.ranks)
    work_items = set(args.work_item)
    assets = load_jsonl(bundle / "data_assets.jsonl")
    selected = []
    for asset in assets:
        if asset.get("tier") not in tiers:
            continue
        if ranks is not None and int(asset.get("rank", 0)) not in ranks:
            continue
        if work_items and not work_items.intersection(asset.get("work_item_ids", [])):
            continue
        if not args.include_alternates and not asset.get("selected_by_default", False):
            continue
        selected.append(asset)
    selected_prefixes = {asset_base_path(asset) + "/" for asset in selected}

    plan: list[dict[str, Any]] = []
    resolver_errors: list[dict[str, Any]] = []
    plan_validation_errors: list[dict[str, Any]] = []
    seen_urls: set[str] = set()
    destination_urls: dict[str, str] = {}
    legacy_groups: dict[str, list[dict[str, str]]] = {}

    def resolve_selected(asset: dict[str, Any]):
        files, errors = resolve_asset(
            asset,
            offline=args.offline,
            timeout=args.timeout,
            retries=args.retries,
        )
        return asset, files, errors

    with concurrent.futures.ThreadPoolExecutor(
        max_workers=max(1, min(args.resolve_workers, len(selected) or 1))
    ) as resolve_executor:
        resolved_assets = list(resolve_executor.map(resolve_selected, selected))

    for asset, files, errors in resolved_assets:
        if errors:
            resolver_errors.append({"artifact_id": asset["artifact_id"], "errors": errors})
        base = asset_base_path(asset)
        for remote in files:
            remote_relative = safe_relative_path(remote.relative_path or remote.name)
            relative_path = f"{base}/{remote_relative}"
            legacy_relative_path = f"{base}/{safe_name(remote.name)}"
            legacy_groups.setdefault(legacy_relative_path, []).append(
                {"url": remote.url, "new_relative_path": relative_path}
            )
            if not allowed_url(remote.url, args.allow_domain):
                plan_validation_errors.append(
                    {
                        "type": "disallowed_url",
                        "url": remote.url,
                        "relative_path": relative_path,
                    }
                )
                continue
            if remote.url in seen_urls:
                continue
            seen_urls.add(remote.url)
            destination_key = relative_path.casefold()
            prior_url = destination_urls.get(destination_key)
            if prior_url is not None and prior_url != remote.url:
                plan_validation_errors.append(
                    {
                        "type": "target_path_collision",
                        "relative_path": relative_path,
                        "first_url": prior_url,
                        "second_url": remote.url,
                    }
                )
                continue
            destination_urls[destination_key] = remote.url
            plan.append(
                {
                    **asdict(remote),
                    "source_relative_path": remote.relative_path,
                    "artifact_id": asset["artifact_id"],
                    "dataset_id": asset["dataset_id"],
                    "paper_id": asset["paper_ids"][0],
                    "rank": asset["rank"],
                    "tier": asset["tier"],
                    "relative_path": relative_path,
                }
            )

    repair_actions = repair_actions_for_selected(
        ledger_repair_actions, selected_prefixes
    )
    active_paths = {item["relative_path"] for item in plan}
    for legacy_relative_path, entries in sorted(legacy_groups.items()):
        urls = {entry["url"] for entry in entries}
        new_paths = {entry["new_relative_path"] for entry in entries}
        if len(urls) > 1 and len(new_paths) > 1 and legacy_relative_path not in active_paths:
            repair_actions.append(
                {
                    "action": "delete_legacy_collision_path",
                    "relative_path": legacy_relative_path,
                    "reason": (
                        f"resolver now preserves hierarchy for {len(urls)} URLs "
                        "that previously shared one basename"
                    ),
                }
            )
    repair_actions = deduplicate_repair_actions(repair_actions)

    if args.max_files and len(plan) > args.max_files:
        plan = plan[: args.max_files]
        active_paths = {item["relative_path"] for item in plan}
    known_bytes = sum(int(item["size"]) for item in plan if item.get("size") is not None)
    if args.max_total_gb and known_bytes > args.max_total_gb * (1024 ** 3):
        print(
            f"Refusing plan: known size {known_bytes / (1024 ** 3):.2f} GiB exceeds --max-total-gb",
            file=sys.stderr,
        )
        return 2

    plan_record = {
        "batch_id": batch_id,
        "generated_at_epoch": time.time(),
        "dry_run": not args.apply,
        "selected_asset_groups": len(selected),
        "resolved_files": len(plan),
        "known_bytes": known_bytes,
        "unknown_size_files": sum(1 for item in plan if item.get("size") is None),
        "resolver_errors": resolver_errors,
        "plan_validation_errors": plan_validation_errors,
        "repair_actions": repair_actions,
        "files": plan,
    }
    plan_path = args.output_root / "download_plan.json"
    write_plan_preserving_previous(plan_path, plan_record)
    print(json.dumps({k: v for k, v in plan_record.items() if k != "files"}, ensure_ascii=False, indent=2))
    print(f"Plan: {plan_path}")
    if plan_validation_errors or resolver_errors:
        print(
            "Refusing incomplete plan: "
            f"{len(plan_validation_errors)} path/domain validation errors; "
            f"{len(resolver_errors)} resolver error groups",
            file=sys.stderr,
        )
        return 2
    if not args.apply:
        print(f"Dry-run only. Review the plan, then use --apply --confirm-reviewed {batch_id}")
        return 0

    lock = threading.Lock()
    failures = 0
    repair_results = perform_repair_actions(
        args.output_root, repair_actions, active_paths
    )
    blocked_repairs = [
        result for result in repair_results
        if result["status"] == "repair_blocked_active_target"
    ]
    if blocked_repairs:
        print(
            f"Refusing download: {len(blocked_repairs)} repair paths overlap active targets",
            file=sys.stderr,
        )
        return 2
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, args.max_workers)) as executor:
        futures = [
            executor.submit(
                download_one,
                item,
                output_root=args.output_root,
                timeout=args.timeout,
                retries=args.retries,
                overwrite=args.overwrite,
                extra_domains=args.allow_domain,
                prior_result=prior_results.get(item["relative_path"]),
            )
            for item in plan
        ]
        with ledger_path.open("a", encoding="utf-8") as ledger:
            for result in repair_results:
                ledger.write(json.dumps(result, ensure_ascii=False) + "\n")
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                if result["status"] in {
                    "failed", "blocked_domain", "existing_unverifiable"
                }:
                    failures += 1
                with lock:
                    ledger.write(json.dumps(result, ensure_ascii=False) + "\n")
                    ledger.flush()
                print(f"{result['status']}: {result['relative_path']}")
    print(f"Download ledger: {ledger_path}; failures={failures}")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
